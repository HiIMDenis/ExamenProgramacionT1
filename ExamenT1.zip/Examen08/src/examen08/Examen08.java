package examen08;
import java.util.*;
import java.lang.Math.*;
import java.util.Scanner.*;

public class Examen08 {

    
    public static void main(String[] args) {
       
        char[] vocales={'a','e','i','o','u'};
        double[]decimales={1,2,3,4,5};
        String[]Lprogramcion={"java","c++"};
      
        
        System.out.println("Esta es la ultima posicon de vocales "+vocales[4]);
        System.out.println("Esta es la ultima posicon de decimales "+decimales[4]);
        System.out.println("Esta es la ultima posicon de lenguajes de programacion "+Lprogramcion[1]);
        Lprogramcion[0]="Cobol";
        System.out.println("Esta es la ultima posicon de lenguajes de programacion "+Lprogramcion[0]);
        
        
        
        
    }
    
}
