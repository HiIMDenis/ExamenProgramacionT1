
package examen05;

import java.util.*;
import java.lang.Math.*;
import java.util.Scanner.*;

public class Examen05 {

   
    public static void main(String[] args) {
        
       
        
        System.out.println("Dime un numero entero");
        int x=new Scanner(System.in).nextInt();
        x+=5;
        System.out.println(+x);
        x-=4;
        System.out.println(+x);
        x++;
        System.out.println(+x);
        x--;
        System.out.println(+x);
        
    }
    
}
