package examen01;

import java.util.*;
import java.lang.Math.*;
import java.util.Scanner.*;

public class Examen01 {

 
    public static void main(String[] args) {
        int n=20;
        double n1=20.0;
        char a=2;
        boolean paco=true;
        long n2=90;
        float pepe=3;
        byte num=2;
        short dos=2;
        
        System.out.println("para representar int "+n);
        System.out.println("para representar double "+n1);
        System.out.println("para representar char "+a);
        System.out.println("para representar int "+n);
        System.out.println("para representar boolean "+paco);
        System.out.println("para representar long "+n2);
        System.out.println("para representar float "+pepe);
        System.out.println("para representar byte "+num);
        System.out.println("para representar short "+dos);
    }
    
}
