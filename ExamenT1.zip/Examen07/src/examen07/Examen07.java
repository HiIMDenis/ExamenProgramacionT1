
package examen07;

import java.util.*;
import java.lang.Math.*;
import java.util.Scanner.*;
public class Examen07 {

   
    public static void main(String[] args) {
        
        String n1 = "123";
        String n2 = "69";
        double nu1=Double.parseDouble(n1);
        double nu2=Double.parseDouble(n2);
        
         System.out.println(nu1+nu2);
         System.out.println(nu1-nu2);
         System.out.println(nu1*nu2);
         System.out.println(nu1/nu2);
         System.out.println(nu1%nu2);
    }
    
}
