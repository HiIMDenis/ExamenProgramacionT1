package examen09;

import java.util.*;
import java.lang.Math.*;
import java.util.Scanner.*;

public class Examen09 {

  
    public static void main(String[] args) {
     
        System.out.println("Dime un numero entre el 10 y el 56");
        int n1= new Scanner(System.in).nextInt();
        
        if ((n1>=10)&(n1<=56)){
            System.out.println("Es correcto");
        }else{
             System.out.println("No es correcto"); 
            }
            
        }
        
        
        
        
        
    }
    

