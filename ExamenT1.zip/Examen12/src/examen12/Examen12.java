
package examen12;
import java.util.*;
import java.lang.Math.*;
import java.util.Scanner.*;

public class Examen12 {

   
    public static void main(String[] args) {
        
        System.out.println("Dime tu eddad");
        int edad=new Scanner(System.in).nextInt();
        
        
        String mayoredad = edad>=18 ? "mayor de edad":"menor de edad";
        System.out.println("Eres "+mayoredad);
        
               
               
               
               
               
        
    }
    
}
