package examen06;

import java.util.*;
import java.lang.Math.*;
import java.util.Scanner.*;
public class Examen06 {

    
    public static void main(String[] args) {
        
    
    char a=201;  
    char b=105;      
    char c=306;      
    char d=407;    
    char e=608;    
    System.out.println(a);
    System.out.println(b);
    System.out.println(c);
    System.out.println(d);
    System.out.println(e);
    
    double a1=(double)a;
    int b1=(int)b;
    long d1=(long)d;
    System.out.println(a1);
    System.out.println(b1);
    System.out.println(d1);
    
    
    }
    
}
