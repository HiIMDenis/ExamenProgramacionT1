/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package examen02;
import java.util.*;
import java.lang.Math.*;
import java.util.Scanner.*;
/**
 *
 * @author usuario-tarde
 */
public class Examen02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       System.out.println("***********");
       System.out.println("** Denis **");
       System.out.println("***********");
       
       System.out.println("Dime una variable de tipo Int");
       int n1=new Scanner(System.in).nextInt();
       System.out.println("Dime una variable de tipo Double");
       double n2=new Scanner(System.in).nextDouble();
       System.out.println("Dime una variable de tipo long");
       long n3=new Scanner(System.in).nextLong();
       System.out.println("Dime una variable de tipo String");
       String letra=new Scanner(System.in).nextLine();
       System.out.println("Dime una variable de tipo Short");
       short n4=new Scanner(System.in).nextShort();
       
       
       
    }
    
}
